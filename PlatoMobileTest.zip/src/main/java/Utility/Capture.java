package Utility;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import io.qameta.allure.Allure;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import io.appium.java_client.android.AndroidDriver;



public class Capture {

    public static void screenShot (AndroidDriver driver, String screenshotName) throws IOException {

        TakesScreenshot scrShot =(TakesScreenshot) driver;
        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
        FileUtils.copyFile(SrcFile, new File("C:\\screenshots\\"+screenshotName+timeStamp+".png "));
    }

    public static void addScreenShotAllure (AndroidDriver driver, String screenshotName) throws IOException {

        Allure.addAttachment(screenshotName, new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
    }


}


