package Utility;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.io.IOException;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;


public class Assert {

    public static void assertElementExist(AndroidDriver driver,MobileElement object) throws IOException
    {
        try {
            assertNotNull(object);
            System.out.println("********Element exist*********");
            Capture.addScreenShotAllure(driver,"assertion success");
        } catch (AssertionError error) {
            Capture.screenShot(driver, "assertHata");
            System.out.println("********Assert Fail !!!!!!!*********");
            throw error;
        }

    }

    public static void assertText(AndroidDriver driver,String expectedText, MobileElement object) throws IOException
    {
        try {
            String actualText = object.getText();
            assertEquals("Text Assertion",expectedText, actualText);
            System.out.println("********Text Assertion Success*********");
            Capture.addScreenShotAllure(driver,"assertion success");
        } catch (AssertionError error) {
            Capture.screenShot(driver, "assertError");
            System.out.println("********Assert Fail !!!!!!!*********");
            throw error;
        }

    }

    public static void assertPartialText(AndroidDriver driver,String expectedText, MobileElement object) throws IOException
    {
        try {
            String actualText = object.getText();
            assertEquals("PartialText Assertion",expectedText, actualText);
            System.out.println("********PartialText Assertion Success*********");
            Capture.addScreenShotAllure(driver,"assertion success");
        } catch (AssertionError error) {
            Capture.screenShot(driver, "assertHata");
            System.out.println("********Assert Fail !!!!!!!*********");
            throw error;
        }

    }
}
