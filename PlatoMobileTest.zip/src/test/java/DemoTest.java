
import Utility.Assert;
import Utility.Find;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DemoTest {

    private AndroidDriver<MobileElement> driver;

    @Before
    public void setUp() throws MalformedURLException  {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:automationName", "UiAutomator2");
        desiredCapabilities.setCapability("appium:deviceName", "Galaxy A7");
        desiredCapabilities.setCapability("appium:udid", "3200de6a461ac5cf");
        desiredCapabilities.setCapability("platformName", "Android");
        desiredCapabilities.setCapability("appium:platformVersion", "10");
        desiredCapabilities.setCapability("appium:appPackage", "com.android.chrome");
        desiredCapabilities.setCapability("appium:appActivity", "com.google.android.apps.chrome.Main");
        desiredCapabilities.setCapability(fullReset, "false");

        //desiredCapabilities.setCapability("appium:ensureWebviewsHavePages", true);
        //desiredCapabilities.setCapability("appium:nativeWebScreenshot", true);
        //desiredCapabilities.setCapability("appium:newCommandTimeout", 3600);
        //desiredCapabilities.setCapability("appium:connectHardwareKeyboard", true);

        URL remoteUrl = new URL("http://127.0.0.1:4723");

        driver = new AndroidDriver<MobileElement>(remoteUrl, desiredCapabilities);
    }

    @Test
    public void sampleTest() throws IOException {
        MobileElement el0 = Find.findElement(driver,"id","com.android.chrome:id/signin_fre_dismiss_button");
        el0.click();
        MobileElement el1 = Find.findElement(driver,"id","com.android.chrome:id/search_box_text");
        Assert.assertText(driver,"Arama yapın veya web adresi yazın",el1);
    }

    @After
    public void tearDown() {
        driver.quit();
    }
}