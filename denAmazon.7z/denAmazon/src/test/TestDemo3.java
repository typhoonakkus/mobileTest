package test;


import org.json.simple.JSONObject;

import java.io.IOException;
import java.net.URL;
import org.json.simple.parser.ParseException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import denAmazon.Assert;
import denAmazon.Capture;
import denAmazon.Data;
import denAmazon.Find;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TestDemo3 {	

	  private AndroidDriver driver;
	  static JSONObject testDatas;
	  String eposta = null ;
	  String sif = null ;
	  

	  @Test(retryAnalyzer = denAmazon.Retry.class)
	  public void sampleTest() throws IOException, ParseException, InterruptedException {
		  
		  DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		    desiredCapabilities.setCapability("deviceName", "Galaxy S6");
		    desiredCapabilities.setCapability("udid", "0915f932eb6e3301");
		    desiredCapabilities.setCapability("platformVersion", "7.0");
		    desiredCapabilities.setCapability("app", "C:\\Users\\typho\\Downloads\\Amazon_App.apk");
		    desiredCapabilities.setCapability("platformName", "Android");
		  

		    URL remoteUrl = new URL("http://localhost:4723/wd/hub");

		    driver = new AndroidDriver(remoteUrl, desiredCapabilities);
		    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		    System.out.println("TEST BASLIYOR ******************");
		    testDatas = (JSONObject)Data.getTestData("JSON");
		    	    	    
		   eposta = (String) testDatas.get("email");
		   sif = (String) testDatas.get("password");
		   
		   
		   System.out.println("DATA ******************"+eposta);
		   System.out.println("DATA ******************"+sif);
		  
			
		MobileElement el0 = Find.findElement(driver,"xpath","/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.TextView");
		el0.click();
	    MobileElement el1 = Find.findElement(driver,"xpath","/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[4]/android.widget.EditText");
	    el1.sendKeys(eposta);
	    Capture.screenShot(driver, "screenshotName");	    
	    MobileElement el2 = Find.findElement(driver, "xpath","/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[6]/android.widget.EditText");
	    el2.sendKeys(sif);	     
	    MobileElement el4 = Find.findElement(driver, "xpath","/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[9]/android.widget.Button");
	    el4.click();	  
	    MobileElement el5 = Find.findElement(driver, "xpath", "//android.view.ViewGroup[@content-desc=\"FOR YOU\"]/android.widget.TextView");
	    Assert.assertElementExist(driver, el5);
	   /* if (el5 != null ) {
	    	System.out.println("assertElement ******************"+el5.getText());	    	
	    }else {
	    	
	    }*/
	    	    		
	  }	
	}



