package denAmazon;


import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;




public class Find {
	
	public static MobileElement findElement (AndroidDriver androidDriver, String locatorType, String locator) throws IOException
	{	
	
	int waitTimeout = 10;
	
		MobileElement element = null;
		try {
			
		switch(locatorType) {
		
		case "id":
			System.out.println("*******Start findelement*********");	
			element = findElementById(androidDriver,locator,waitTimeout);
			System.out.println("********Finish find element*********");
		break;
		case "accessibilityId":
			System.out.println("*******Start findelement*********");	
			element = findElementByAccessibilityId(androidDriver,locator,waitTimeout);
			System.out.println("********Finish find element*********");
		break;
		case "xpath":
			System.out.println("*******Start findelement*********");	
			element = findElementByXPath(androidDriver,locator,waitTimeout);
			System.out.println("********Finish find element*********");
		break;
		}
	} catch (Exception e) {
		System.out.println("******Error occured while try to find element!!!!!!!!!"+" "+e+" "+ locator);
		Capture.screenShot(androidDriver, "ErrorFindElement");
		
	}
		return element;

	}


	private static MobileElement findElementById (AndroidDriver driver, String id, int waitTimeout)
	
	{
		MobileElement element = null;
	
		WebDriverWait wait = new WebDriverWait(driver, waitTimeout);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		element = (MobileElement) driver.findElementById(id);

		System.out.println("***************findElementById ENABLED DISPLAYED: "+ element.isEnabled() + "\n" +"*******FOUND ELEMENT: " +element);
	
		return element;
	}
	
	private static MobileElement findElementByAccessibilityId (AndroidDriver driver, String accessibilityId, int waitTimeout)
	
	{
		MobileElement element = null;
	
		
		element = (MobileElement) driver.findElementByAccessibilityId(accessibilityId);

		System.out.println("***************findElementByAccessibilityId ENABLED DISPLAYED: "+ element.isEnabled() + "\n" +"*******FOUND ELEMENT: " +element);
	
		return element;
	}
	
private static MobileElement findElementByXPath (AndroidDriver driver, String xPath, int waitTimeout)
	
	{
		MobileElement element = null;
	
		
		element = (MobileElement) driver.findElementByXPath(xPath);

		System.out.println("***************findElementByXPath ENABLED DISPLAYED: "+ element.isEnabled() + "\n" +"*******FOUND ELEMENT: " +element);
	
		return element;
	}
}



