package denAmazon;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;


import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

public class TestDemo {	

	  private AndroidDriver driver;

	  @Before
	  public void setUp() throws IOException {
	    DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
	    desiredCapabilities.setCapability("deviceName", "Galaxy S6");
	    desiredCapabilities.setCapability("udid", "0915f932eb6e3301");
	    desiredCapabilities.setCapability("platformVersion", "7.0");
	    desiredCapabilities.setCapability("app", "C:\\Users\\typho\\Downloads\\selendroid-test-app.apk");
	    desiredCapabilities.setCapability("platformName", "Android");
	    desiredCapabilities.setCapability("ensureWebviewsHavePages", true);
	    desiredCapabilities.setCapability("unicodeKeyboard", false);
	    desiredCapabilities.setCapability("resetKeyboard", false);

	    URL remoteUrl = new URL("http://localhost:4723/wd/hub");

	    driver = new AndroidDriver(remoteUrl, desiredCapabilities);
	    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	  }

	  @Test
	  public void sampleTest() throws IOException {
	    MobileElement el1 = Find.findElement(driver,"accessibilityId","my_text_fieldCD");
	    el1.click();
	    Capture.screenShot(driver, "screenshotName");
	    el1.sendKeys("deneme");
	    MobileElement el2 = Find.findElement(driver, "accessibilityId","waitingButtonTestCD");
	    el2.click();
	    MobileElement el3 = Find.findElement(driver, "id","io.selendroid.testapp:id/inputUsername");
	    el3.sendKeys("denemeler");	    
	    MobileElement el4 = Find.findElement(driver, "id","io.selendroid.testapp:id/btnRegisterUser");
	    el4.click();
	    Assert.assertElementExist(driver, el4);
	  }	
	}



