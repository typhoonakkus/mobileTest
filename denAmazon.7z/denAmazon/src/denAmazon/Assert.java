package denAmazon;


import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;



public class Assert {
	
	public static void assertElementExist(AndroidDriver driver,MobileElement object) throws IOException
	{
		try {
		assertNotNull(object);
		System.out.println("********Element exist*********");
		Capture.screenShot(driver, "assertion");
	} catch (AssertionError error) {
		Capture.screenShot(driver, "assertHata");
		System.out.println("********Assert Fail !!!!!!!*********");
		throw error;
	}

}
}
