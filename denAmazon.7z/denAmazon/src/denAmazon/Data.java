package denAmazon;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.parser.ParseException;
	
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;





public class Data {
	
	public static Object getTestData(String dataType) throws IOException, ParseException {
		Object testData = new Object();
		switch(dataType)
		{
		case "JSON":
			System.out.println("case JSON **********");
			testData = GetJSONData();
			System.out.println("case JSON FINITO **********");
			break;
			
		default:
			System.out.println("The data type you state does NOT exist!!!");
			break;
		}
		
		return testData;
	}
	
	public static JSONObject GetJSONData() throws IOException, ParseException {
		
		
		JSONParser parser = new JSONParser();		
		File file = new File(".\\resources\\testData\\data.json");
		JSONArray jsonArray = (JSONArray)parser.parse(new FileReader(file));
		JSONObject jsonObject = (JSONObject)jsonArray.get(0);
		System.out.println("case JSON**********"+jsonObject);
		return jsonObject;
		
	}
	


}
